﻿namespace PrivCalcAssembly
{
    public class CalcAssembly
    {
        static void Main()
        {
            //Do Nothing
        }

        //Addition
        public float Addition(float num1, float num2)
        {
            return num1 + num2;
        }
        public float Multiplication(float num1, float num2)
        {
            return num1 * num2;
        }
        public float Division(float num1, float num2)
        {
            return num1 / num2;
        }
        public float Subtraction(float num1, float num2)
        {
            return num1 - num2;
        }
    }

}